import java.io.IOException;
import java.time.LocalTime;

public class Main {
    public static void main(String[] args) throws InterruptedException, IOException {
        Graphics g = new Graphics();
        UserInput input = new UserInput();
        MainMenu menu = new MainMenu();

        while (true) {
            /* Set main menu as first scene */
            input.setScene(menu);
            g.setScene(menu);
            do {
                g.draw(); ///< Draw main menu
            }
            while (!input.process()); ///< If menu item selected, continue

            /* Get game mode selected in main menu */
            int[] game_setup = menu.getSelection();
            if (game_setup == null) { ///< If no selection or selected EXIT, quit
                break;
            }

            /* Create new game field with selected game mode */
            Field field = new Field(game_setup[0], game_setup[1], game_setup[2]);
            /* Start gameplay timer */
            int start_time = LocalTime.now().getSecond();

            /* Set new field to render */
            input.setScene(field);
            g.setScene(field);
            do {
                g.draw(); ///< Draw field
            }
            while (!input.process());
            g.draw(); ///< draw all revealed fields, since after game stopped it wasn't updated

            /* Display information about game */
            int time_elapsed = LocalTime.now().getSecond() - start_time;
            if (field.getWinning()) {
                System.out.println("Congratulations! Time elapsed " + time_elapsed + " sec");
            } else {
                System.out.println("You landed on bomb!");
            }

            System.out.println("Press any key to return to main page...");
            input.process(); ///< Wait
        }
    }
}
