package oop;

import javax.net.ssl.HttpsURLConnection;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

public class ChessBot {
    private int rating;
    private String url = "https://chesshub.com/api/v1/fens.json";

    public ChessBot(int rating){
        this.rating = rating; ///< Chess rating standard to use
    }

    public String[] getNextStep(String FEN) throws IOException {
        String urlParameters  = "fen=\"" + URLEncoder.encode(FEN, StandardCharsets.UTF_8)+ "\"&rating=" + rating;

        URL u = new URL(url+"?"+urlParameters); ///< Generate url with query
        HttpsURLConnection conn = (HttpsURLConnection)u.openConnection();
        conn.setRequestProperty("Accept-Charset", "UTF-8");

        BufferedReader buf = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        String input;

        String response = "";
        while ((input = buf.readLine()) != null){ ///< Read in all response data (json format)
            //System.out.println(input);
            response += input;
        }
        buf.close();

        // Find button location to move from
        String from_pattern = "\"from\":\"";
        int from_index = response.indexOf(from_pattern)+from_pattern.length();
        String from = response.substring(from_index, from_index+2);

        // Find button location to move
        String to_pattern = "\"to\":\"";
        int to_index = response.indexOf(to_pattern)+to_pattern.length();
        String to = response.substring(to_index, to_index+3);
        to = to.replace("\"", "");

        return new String[]{from, to};
    }

    public static void main(String[] args) throws IOException {
        ChessBot bot = new ChessBot(1200);
        System.out.println(Arrays.toString(bot.getNextStep("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1")));
    }
}
