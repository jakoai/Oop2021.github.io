public class ItemNumber extends Item{
    private String color;
    private String numbercolor;

    public ItemNumber(Integer symbol) {
        super(String.valueOf((char)('0'+symbol)));
        numbercolor = generateColor(symbol);
    }

    /* Generate specific color for each number */
    private String generateColor(int symbol){
        switch (symbol){
            case 1:
                return Colors.Blue;
            case 2:
                return Colors.Green;
            case 3:
                return Colors.Red;
            case 4:
                return Colors.Cyan;
            case 5:
                return Colors.Magenta;
            case 6:
                return Colors.Yellow;
            case 7:
                return Colors.color((byte)245);
            case 8:
                return Colors.White;
            default:
                return Colors.Reset;
        }
    }

    /* Define items default color */
    @Override
    public String color() {
        if (getSelected()){
            return Colors.Reversed+numbercolor;
        }
        return numbercolor;
    }

    @Override
    public boolean isEmpty() {
        return false;
    }

    /* Reveal number when item is not marked */
    @Override
    public boolean reveal() {
        if (!getMarked()) {
            setHidden(false);
        }
        return false;
    }
}
