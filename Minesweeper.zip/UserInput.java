import javax.swing.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class UserInput {
    private int[] selected = new int[2];
    private Scene scene;
    private Item lastSelectedItem;

    public void reset(){
        selected[0] = 0;
        selected[1] = 0;
        switchSelection();
    }

    /* Make last item not selected and new item selected */
    private void switchSelection(){
        if (lastSelectedItem != null) {
            lastSelectedItem.setSelected(false);
        }
        Item newItem = scene.getItem(selected[0], selected[1]);
        newItem.setSelected(true);
        lastSelectedItem = newItem;
    }

    public void setScene(Scene scene) {
        this.scene = scene;
        reset();
    }

    public boolean process(){
        int ch = getCh(); ///< Get keyboard key code from window
        /* Move selected item */
        switch (ch){
            case 38:///< Up
                if (selected[1]-1 >= 0){
                    selected[1] -= 1;
                }
                break;
            case 37:///< Left
                if (selected[0]-1 >= 0){
                    selected[0] -= 1;
                }
                break;
            case 40:///< Down
                if (selected[1]+1 < scene.getSize()[1]){
                    selected[1] += 1;
                }
                break;
            case 39:///< Right
                if (selected[0]+1 < scene.getSize()[0]){
                    selected[0] += 1;
                }
                break;
        }

        switchSelection();

        /* Send scene pressed key and currently selected item */
        return scene.select(selected[0], selected[1], ch);
    }

    /* Creates an invisible window to detect keyboard input
    https://stackoverflow.com/questions/1864076/equivalent-function-to-cs-getch-in-java */
    public static int getCh() {
        final JFrame frame = new JFrame();
        final int[] key = new int[1];
        synchronized (frame) {
            frame.setUndecorated(true);
            frame.getRootPane().setWindowDecorationStyle(JRootPane.FRAME);
            frame.addKeyListener(new KeyListener() {
                @Override
                public void keyPressed(KeyEvent e) {
                    key[0] = e.getKeyCode();
                    synchronized (frame) {
                        frame.setVisible(false);
                        frame.dispose();
                        frame.notify();
                    }
                }

                @Override
                public void keyReleased(KeyEvent e) {
                }

                @Override
                public void keyTyped(KeyEvent e) {
                }
            });
            frame.setVisible(true);
            try {
                frame.wait();
            } catch (InterruptedException e1) {
            }
        }
        return key[0];
    }
}
