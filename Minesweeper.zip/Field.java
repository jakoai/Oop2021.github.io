import java.util.ArrayList;
import java.util.List;

public class Field implements Scene {
    private int size_x;
    private int size_y;
    private int number_of_bombs;
    private Item[][] map;
    private int bombs_found = 0;;

    public Field(int size_x, int size_y, int number_of_bombs) {
        this.size_x = size_x;
        this.size_y = size_y;
        this.number_of_bombs = number_of_bombs;
        this.generate();
    }

    @Override
    public int[] getSize() {
        return new int[]{size_x, size_y};
    }

    @Override
    public Item getItem(int x, int y) {
        return map[y][x];
    }

    /* Generate all possible coordinates over target position */
    private List<int[]> getNeighborsCoordinates(int x, int y) {
        List<int[]> coordinates = new ArrayList<>();
        /* All possible locations delta range */
        int[] targetx = {-1, 0, 1};
        int[] targety = {-1, 0, 1};

        for (int tx : targetx) {
            int cx = x + tx;
            if (cx >= 0 && cx <= size_x - 1) {
                for (int ty : targety) {
                    int cy = y + ty;
                    if (cy >= 0 && cy <= size_y - 1) {
                        coordinates.add(new int[]{cx, cy});
                    }
                }
            }
        }
        return coordinates;
    }

    /* Fills map with items */
    private void generate() {
        map = new Item[size_y][size_x];
        for (int y = 0; y < map.length; y++) {
            Item[] line = map[y];
            for (int x = 0; x < line.length; x++) {
                map[y][x] = new ItemEmpty();
            }
        }

        /* Generate bombs to the map */
        for (int i = 0; i < number_of_bombs; i++) {
            int posx = (int) Math.floor(Math.random() * size_x);
            int posy = (int) Math.floor(Math.random() * size_y);

            /* Check if random position value is 1 to not make sizes go over boundaries */
            if (posx > size_x - 1) {
                posx = size_x - 1;
            }
            if (posy > size_y - 1) {
                posy = size_y - 1;
            }
            /* Try again if bomb item already there */
            if (map[posy][posx].isEmpty()) {
                map[posy][posx] = new ItemBomb();
            } else {
                i--; ///< Go back one index, since there was no valid bomb to add to the field
            }
        }

        /* check each map coordinate and count bombs near them, then create items */
        for (int y = 0; y < map.length; y++) {
            Item[] line = map[y];
            for (int x = 0; x < line.length; x++) {
                int bomb_count = 0;
                if (!map[y][x].isBomb()) {
                    for (int[] neighbor : getNeighborsCoordinates(x, y)) {
                        if (map[neighbor[1]][neighbor[0]].isBomb()) {
                            bomb_count += 1;
                        }
                    }
                    if (bomb_count != 0) {
                        map[y][x] = new ItemNumber(bomb_count);
                    }
                }
            }
        }
    }

    /* Return when players field is in winning situation */
    public boolean getWinning() {
        int fields_revealed = 0;
        for (int y = 0; y < map.length; y++) {
            Item[] line = map[y];
            for (int x = 0; x < line.length; x++) {
                Item item = line[x];
                if (item.isBomb()) {
                    if (item.getSelected()) return false; ///< Return defeat when player selected a bomb
                } else {
                    fields_revealed += item.getHidden() ? 0 : 1;
                }
            }
        }
        return fields_revealed == size_x * size_y - number_of_bombs;
    }

    /* Recursively reveals all empty spaces nearby */
    private void revealEmptySpot(int x, int y) {
        Item item = getItem(x, y);
        if (!item.getHidden()) {
            return;
        }
        item.reveal();
        if (item.isEmpty()) {
            for (int[] pos : getNeighborsCoordinates(x, y)) {
                revealEmptySpot(pos[0], pos[1]);
            }
        }
    }

    /* Called by userinput, that sends it selected items position and keyboard character
     return true, when game is over */
    @Override
    public boolean select(int x, int y, int ch) {
        Item item = getItem(x, y);
        switch (ch) {
            /* Logic for revealing selected item */
            case 10:   ///< Enter
                if (item.isEmpty()) {
                    revealEmptySpot(x, y);
                    return false;
                }
                boolean stop = item.reveal() || getWinning(); ///< Return true if stepped on bomb
                if (stop) {
                    revealAll();
                }
                return stop || getWinning();
            /* Count marked bombs */
            case 70:   ///< F
                boolean is_new = item.toggleMarked();
                bombs_found += is_new ? 1 : -1;
        }
        return false; ///< Return false when game doesn't end
    }

    /* Graphical output for graphics generator */
    @Override
    public String getGraphics() {
        StringBuilder out = new StringBuilder();
        out.append("Bombs remaining: " + (number_of_bombs - bombs_found) + "\n");
        for (int y = 0; y < map.length; y++) {
            Item[] line = map[y];
            for (int x = 0; x < line.length; x++) {
                Item item = line[x];
                out.append(item);
            }
            out.append('\n');
        }
        out.append(Colors.Reversed + "Move: arrows, Reveal: enter, Mark/Unmark: F" + Colors.Reset + "\n");
        return out.toString();
    }

    /* Reveal all items, used when player loses */
    public void revealAll() {
        for (int y = 0; y < map.length; y++) {
            Item[] line = map[y];
            for (int x = 0; x < line.length; x++) {
                Item item = line[x];
                item.reveal();
            }
        }
    }
}
