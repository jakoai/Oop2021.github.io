/* Menu items */
public class ItemMenu extends Item{

    public ItemMenu(String text) {
        super(text);
        setHidden(false);
    }

    @Override
    public boolean reveal() {
        return false;
    }

    @Override
    public String toString() {
        return super.getColor()+super.getText()+Colors.Reset;
    }
}
