package oop;

import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.*;
import java.util.stream.IntStream;

public class Main extends Application {

    private static final short GRID_SIZE = 8;
    private static final short IMAGE_SIZE = 60;
    private static final String DEFAULT_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";
    private static final char[] BUTTON_NAMES = new char[]{'b', 'k', 'n', 'p', 'q', 'r',
                                                         'B', 'K', 'N', 'P', 'Q', 'R'};
    private final Map<Character, Integer> getImageBySign = new HashMap<>(){};
    private final BoardChecker maleLaud = new BoardChecker(DEFAULT_FEN);
    private final String title_prefix = "Chess - ";
    private final char player_turn = 'w';

    private char[][] lauaNupud;
    private char winner = 0;
    private short[] selected;
    private short count;
    private int rating = -1;
    private int selected_mode = -1;
    private Image[] pildid;
    private ArrayList<int[]> possible = new ArrayList<>();
    private ChessBot computer = null;


    private void Initialize(){
        winner = 0;
        for(int i = 0; i < BUTTON_NAMES.length; i++)
            getImageBySign.put(BUTTON_NAMES[i], i);

        maleLaud.setFEN(DEFAULT_FEN);
        lauaNupud = generateBoardCharArray(DEFAULT_FEN.split(" ")[0]);

        try {
            pildid = loadImages();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            throw new RuntimeException("Error while loading images");
        }

        if (rating != -1){
            computer = new ChessBot(rating);
        } else {
            computer = null;
        }
    }

    @Override
    public void start(Stage peaLava){

        StringProperty title = new SimpleStringProperty(title_prefix+"Main menu");
        peaLava.titleProperty().bind(title);

        short minScreenWidth = GRID_SIZE * IMAGE_SIZE;
        short minScreenHeight = GRID_SIZE * IMAGE_SIZE;

        Initialize();

        Canvas canvas = new Canvas(minScreenWidth, minScreenHeight);
        GraphicsContext gc = canvas.getGraphicsContext2D();
        gc.setFont(new Font(60));

        Pane board = new Pane();
        board.setMinWidth(minScreenWidth);
        board.setMinHeight(minScreenHeight);
        board.getChildren().add(canvas);

        Scene s1 = new Scene(board);


        Canvas menu_canvas = new Canvas(minScreenWidth, minScreenHeight);
        GraphicsContext menu_gc = menu_canvas.getGraphicsContext2D();

        Pane menu = new Pane();
        menu.setMinWidth(minScreenWidth);
        menu.setMinHeight(minScreenHeight);
        HBox hbox = new HBox();
        hbox.setMinWidth(minScreenWidth);
        hbox.setAlignment(Pos.CENTER);
        VBox vbox = new VBox();
        vbox.setMinHeight(minScreenHeight);
        vbox.setAlignment(Pos.CENTER);
        Text easy = new Text("Computer - Easy");
        easy.setFont(Font.font("comic sans", FontWeight.BOLD, 40));
        easy.setFill(Color.WHITE);
        easy.setStroke(Color.BLACK);

        Text medium = new Text("Computer - Medium");
        medium.setFont(new Font("comic sans", 40));
        medium.setFont(Font.font("comic sans", FontWeight.BOLD, 40));
        medium.setFill(Color.WHITE);
        medium.setStroke(Color.BLACK);

        Text hard = new Text("Computer - Hard");
        hard.setFont(new Font("comic sans", 40));
        hard.setFont(Font.font("comic sans", FontWeight.BOLD, 40));
        hard.setFill(Color.WHITE);
        hard.setStroke(Color.BLACK);

        Text human = new Text("Play Multiplayer Mode");
        human.setFont(new Font("comic sans", 40));
        human.setFont(Font.font("comic sans", FontWeight.BOLD, 40));
        human.setFill(Color.WHITE);
        human.setStroke(Color.BLACK);

        menu.getChildren().add(menu_canvas);
        vbox.getChildren().add(easy);
        vbox.getChildren().add(medium);
        vbox.getChildren().add(hard);
        vbox.getChildren().add(human);
        hbox.getChildren().add(vbox);
        menu.getChildren().add(hbox);


        vbox.prefWidthProperty().bind(menu.widthProperty());
        hbox.prefHeightProperty().bind(menu.heightProperty());

        Scene s2 = new Scene(menu);

        peaLava.heightProperty().addListener(e -> {
            canvas.setHeight(peaLava.getHeight());
            menu_canvas.setHeight(peaLava.getHeight());
            drawBoard(peaLava.getWidth(), peaLava.getHeight(), gc);
            drawBoardBackground(peaLava.getWidth(), peaLava.getHeight(), menu_gc);
        });
        peaLava.widthProperty().addListener(e -> {
            canvas.setWidth(peaLava.getWidth());
            menu_canvas.setWidth(peaLava.getWidth());
            drawBoard(peaLava.getWidth(), peaLava.getHeight(), gc);
            drawBoardBackground(peaLava.getWidth(), peaLava.getHeight(), menu_gc);
        });

        board.setOnMouseClicked(e -> {
            if (winner == 0) {
                mouseHandler(e.getSceneX(), e.getSceneY(), peaLava.getWidth(), peaLava.getHeight(), gc);
                if (maleLaud.getTurn() != player_turn && computer != null){
                    title.setValue(title_prefix+"Computer turn");
                    drawBoard(peaLava.getWidth(), peaLava.getHeight(), gc);
                    computerTurn();
                }
                title.setValue(title_prefix+(maleLaud.getTurn()=='w'?"White turn":"Black turn"));
                drawBoard(peaLava.getWidth(), peaLava.getHeight(), gc);
            } else {
                title.setValue(title_prefix+"Main menu");
                peaLava.setScene(s2);
            }
            drawGameOver(title, canvas.getWidth(), canvas.getHeight(), gc);
        });

        easy.setOnMouseClicked(e -> {
            Initialize();
            title.setValue(title_prefix+(maleLaud.getTurn()=='w'?"White turn":"Black turn"));
            peaLava.setScene(s1);
        });

        medium.setOnMouseClicked(e -> {
            Initialize();
            title.setValue(title_prefix+(maleLaud.getTurn()=='w'?"White turn":"Black turn"));
            peaLava.setScene(s1);
        });

        hard.setOnMouseClicked(e -> {
            Initialize();
            title.setValue(title_prefix+(maleLaud.getTurn()=='w'?"White turn":"Black turn"));
            peaLava.setScene(s1);
        });

        human.setOnMouseClicked(e -> {
            Initialize();
            title.setValue(title_prefix+(maleLaud.getTurn()=='w'?"White turn":"Black turn"));
            peaLava.setScene(s1);
        });

        s2.setOnKeyPressed(e -> {
            if (e.getCode() == KeyCode.ENTER){
                if (selected_mode != -1){
                    Initialize();
                    title.setValue(title_prefix+(maleLaud.getTurn()=='w'?"White turn":"Black turn"));
                    peaLava.setScene(s1);
                }
            }
        });

        easy.setOnMouseEntered( event -> {
            selected_mode = 0;
            rating = 400;
            easy.setFill(Color.AQUA);
            medium.setFill(Color.WHITE);
            hard.setFill(Color.WHITE);
            human.setFill(Color.WHITE);
        });
        easy.setOnMouseExited( event -> {
            selected_mode = -1;
            easy.setFill(Color.WHITE);
        });

        medium.setOnMouseEntered( event -> {
            selected_mode = 1;
            rating = 1200;
            easy.setFill(Color.WHITE);
            medium.setFill(Color.AQUA);
            hard.setFill(Color.WHITE);
            human.setFill(Color.WHITE);
        });
        medium.setOnMouseExited( event -> {
            selected_mode = -1;
            medium.setFill(Color.WHITE);
        });

        hard.setOnMouseEntered( event -> {
            selected_mode = 2;
            rating = 2400;
            easy.setFill(Color.WHITE);
            medium.setFill(Color.WHITE);
            hard.setFill(Color.AQUA);
            human.setFill(Color.WHITE);
        });
        hard.setOnMouseExited( event -> {
            selected_mode = -1;
            hard.setFill(Color.WHITE);
        });

        human.setOnMouseEntered( event -> {
            selected_mode = 3;
            rating = -1;
            easy.setFill(Color.WHITE);
            medium.setFill(Color.WHITE);
            hard.setFill(Color.WHITE);
            human.setFill(Color.AQUA);
        });
        human.setOnMouseExited( event -> {
            selected_mode = -1;
            human.setFill(Color.WHITE);
        });

        //buttonSelectorStage();

        peaLava.setMinWidth(minScreenWidth);
        peaLava.setMinHeight(minScreenHeight);
        peaLava.setScene(s2);
        peaLava.show();
    }

    // Pop-up screen when pawn reaches the top(or bottom)
    private void buttonSelectorStage(String from, String to, double main_w, double main_h, GraphicsContext main_gc){
        Stage stage = new Stage();

        short minScreenWidth = 2 * IMAGE_SIZE;
        short minScreenHeight = 2 * IMAGE_SIZE;

        Canvas canvas = new Canvas(minScreenWidth, minScreenHeight);
        GraphicsContext gc = canvas.getGraphicsContext2D();

        drawButtonSelector(stage.getWidth(), stage.getHeight(), gc);

        stage.heightProperty().addListener(e -> {
            canvas.setHeight(stage.getHeight());
            drawButtonSelector(stage.getWidth(), stage.getHeight(), gc);
        });
        stage.widthProperty().addListener(e -> {
            canvas.setWidth(stage.getWidth());
            drawButtonSelector(stage.getWidth(), stage.getHeight(), gc);
        });

        Group juur = new Group();
        juur.getChildren().add(canvas);

        juur.setOnMouseClicked(e -> {
            if (e.getSceneX() < stage.getWidth() / 2) {
                if (e.getSceneY() < stage.getHeight() / 2) {
                    maleLaud.move(from, to+(maleLaud.getTurn()== 'w' ? 'R' : 'r'));
                } else {
                    maleLaud.move(from, to+(maleLaud.getTurn() == 'w' ? 'Q' : 'q'));
                }
            } else {
                if (e.getSceneY() < stage.getHeight() / 2) {
                    maleLaud.move(from, to+(maleLaud.getTurn() == 'w' ? 'N' : 'n'));
                } else {
                    maleLaud.move(from, to+(maleLaud.getTurn() == 'w' ? 'B' : 'b'));
                }
            }
            lauaNupud = generateBoardCharArray(maleLaud.generateFEN().split(" ")[0]);
            selected = null;
            possible = new ArrayList<>();

            drawBoard(main_w, main_h, main_gc);

            stage.close();
        });

        Scene scene = new Scene(juur);
        stage.setMinWidth(minScreenWidth);
        stage.setMinHeight(minScreenHeight);
        stage.setScene(scene);
        stage.initStyle(StageStyle.UNIFIED);
        stage.setTitle("Choose new button");
        stage.show();
    }

    private void drawButtonSelector(double w, double h, GraphicsContext gc){
        w = fixWindowScreenOffsetX(w)/2;
        h = fixWindowScreenOffsetY(h)/2;

        char [][] lauaNupud_valik;
        if (maleLaud.getTurn() == 'w'){
            lauaNupud_valik = new char[][]{{'R', 'N'},{'Q', 'B'}};
        } else {
            lauaNupud_valik = new char[][]{{'r', 'n'},{'q', 'b'}};
        }

        boolean brownsquare = false;
        for(char i = 0; i < 2; i++) {
            for(char j = 0; j < 2; j++) {
                if(brownsquare) {
                    gc.setFill(Color.BROWN);
                } else {
                    gc.setFill(Color.BEIGE);
                }

                gc.fillRect(j * w, i * h, (j + 1) * w, (i + 1) * h);
                if(lauaNupud_valik[i][j] > 64) {
                    gc.drawImage(pildid[getImageBySign.get(lauaNupud_valik[i][j])],
                            ((j * w - IMAGE_SIZE + w) + (j * w))/2, ((i * h - IMAGE_SIZE + h) + (i * h))/2);
                }
                brownsquare = !brownsquare;
            }
            brownsquare = !brownsquare;
        }
    }

    private void drawGameOver(StringProperty title, double w, double h, GraphicsContext gc){
        if (winner != 0) {
            Text text;
            if (winner == 'w') {
                title.setValue(title_prefix+"White won!");
                text = new Text("White won!");
            } else if (winner == 'b') {
                title.setValue(title_prefix+"Black won!");
                text = new Text("Black won!");
            } else {
                title.setValue(title_prefix+"Stalemate!");
                text = new Text("Stalemate!");
            }
            text.setFont(new Font("comic sans", 60));

            final double text_width = text.getLayoutBounds().getWidth();

            gc.setFill(Color.AQUA);
            gc.setFont(text.getFont());
            gc.fillText(text.getText(), w/2-text_width/2, h/2);
        }
    }

    private char[][] generateBoardCharArray(String FEN) {
        char[][] board = new char[GRID_SIZE][GRID_SIZE];
        for(short i = 0; i < FEN.split("/").length; i++) {
            char[] temp = new char[GRID_SIZE];
            count = 0;
            for(char j : FEN.split("/")[i].toCharArray()) {
                if(j < 58 && j > 47) {
                    IntStream.range(0, Character.getNumericValue(j)).forEach(n -> {
                        temp[count] = ' ';
                        count++;
                    });
                }
                else {
                    temp[count] = j;
                    count++;
                }
            }
            board[i] = temp;
        }
        return board;
    }

    private void drawBoardBackground(double w, double h, GraphicsContext gc){
        w = getGridSize(fixWindowScreenOffsetX(w));
        h = getGridSize(fixWindowScreenOffsetY(h));

        boolean brownsquare = false;
        for(char i = 0; i < GRID_SIZE; i++) {
            for(char j = 0; j < GRID_SIZE; j++) {
                if(brownsquare) {
                    gc.setFill(Color.BROWN);
                }
                else {
                    gc.setFill(Color.BEIGE);
                }

                if(selected != null) {
                    if(j == selected[0] && i == selected[1])
                        gc.setFill(Color.GREEN);
                    if(checkIfTileIsInPossible(i, j))
                        gc.setFill(Color.LIGHTGREEN);
                }

                if (maleLaud.checkFire()) {
                    if (lauaNupud[i][j] == 'k' && maleLaud.getTurn() == 'b') {
                        gc.setFill(Color.RED);
                    }
                    if (lauaNupud[i][j] == 'K' && maleLaud.getTurn() == 'w') {
                        gc.setFill(Color.RED);
                    }
                }

                gc.fillRect(j * w, i * h, (j + 1) * w, (i + 1) * h);
                brownsquare = !brownsquare;
            }
            brownsquare = !brownsquare;
        }
    }

    private void drawBoard(double w, double h, GraphicsContext gc) {
        drawBoardBackground(w, h, gc);

        w = getGridSize(fixWindowScreenOffsetX(w));
        h = getGridSize(fixWindowScreenOffsetY(h));

        // Iterate through the board
        for(char i = 0; i < GRID_SIZE; i++) {
            for(char j = 0; j < GRID_SIZE; j++) {
                if(lauaNupud[i][j] > 64) {
                    gc.drawImage(pildid[getImageBySign.get(lauaNupud[i][j])],
                            ((j * w - IMAGE_SIZE + w) + (j * w))/2, ((i * h - IMAGE_SIZE + h) + (i * h))/2);
                }
            }
        }
    }

    private boolean checkIfTileIsInPossible(char y, char x) {
        for(int[] i : possible) {
            if(y == i[0] && x == i[1])
                return true;
        }
        return false;
    }

    private boolean checkIfClickedIsInPossible(short[] coord) {
        for(int[] i : possible) {
            if(i[0] == coord[1] && i[1] == coord[0])
                return true;
        }
        return false;
    }

    // Check is game is over
    private void checkMateOrStalemate(){
        Map<String, Set<String>> all_possible = maleLaud.getAllPossibleSteps();
        boolean cant_move = true;
        for (String key:all_possible.keySet()) {
            if (all_possible.get(key).size() > 0){
                cant_move = false;
                break;
            }
        }
        if (cant_move){
            if (maleLaud.checkFire()){
                System.out.println("MATT, PÄTAKAS");
                winner = (maleLaud.getTurn()=='w'?'b':'w');
            } else {
                System.out.println("NICE, stalemate");
                winner = 1;
            }
        }
    }

    private void computerTurn(){
        // System.out.println("computer turn");
        try {
            String[] computer_move = computer.getNextStep(maleLaud.generateFEN());
            maleLaud.move(computer_move[0], computer_move[1]);
            checkMateOrStalemate();
        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException("Error during computer next step request");
        }

        lauaNupud = generateBoardCharArray(maleLaud.generateFEN().split(" ")[0]);
        selected = null;
        possible = new ArrayList<>();
    }

    private void mouseHandler(double mouseX, double mouseY, double stageWidth, double stageHeight, GraphicsContext gc) {
        double screenX = getGridSize(fixWindowScreenOffsetX(stageWidth));
        double screenY = getGridSize(fixWindowScreenOffsetY(stageHeight));

        short[] tempSelected = new short[]{(short) Math.floor(mouseX/screenX), (short) Math.floor(mouseY/screenY)};

        if(Arrays.equals(tempSelected, selected)) {
            selected = null;
            possible = new ArrayList<>();
            return;
        }

        String coord = ((char)(tempSelected[0] + 'a')) + String.valueOf(Math.abs(tempSelected[1]-GRID_SIZE));

        if(selected != null && checkIfClickedIsInPossible(tempSelected)) {
            if (maleLaud.getTurn()=='w' && coord.contains("8") && lauaNupud[selected[1]][selected[0]] == 'P'){
                buttonSelectorStage(maleLaud.toCoordinate(selected[0], selected[1]), coord, stageWidth, stageHeight, gc);
            } else if (maleLaud.getTurn()=='b' && coord.contains("1") && lauaNupud[selected[1]][selected[0]] == 'p'){
                buttonSelectorStage(maleLaud.toCoordinate(selected[0], selected[1]), coord, stageWidth, stageHeight, gc);
            } else {
                maleLaud.move(maleLaud.toCoordinate(selected[0], selected[1]), coord);
            }
            checkMateOrStalemate();
            lauaNupud = generateBoardCharArray(maleLaud.generateFEN().split(" ")[0]);
            selected = null;
            possible = new ArrayList<>();
            return;
        }

        if(lauaNupud[tempSelected[1]][tempSelected[0]] == ' ')
            return;

        if (maleLaud.getTurn() == 'b' && "PRBNQK".contains(String.valueOf(lauaNupud[tempSelected[1]][tempSelected[0]]))) {
            return;
        }
        if (maleLaud.getTurn() == 'w' && "prbnqk".contains(String.valueOf(lauaNupud[tempSelected[1]][tempSelected[0]]))) {
            return;
        }

        //System.out.println(maleLaud.generateFEN());
        Set<String> possibleMoveSet = maleLaud.getPossibleSteps(coord);
        possible = new ArrayList<>();
        for(String i : possibleMoveSet)
            possible.add(maleLaud.toCoordinateXY(i));

        selected = tempSelected;
    }

    // Load images from resources directory
    // Got them from here: https://commons.wikimedia.org/wiki/Category:PNG_chess_pieces/Standard_transparent
    private Image[] loadImages() throws FileNotFoundException {
        String resourcesPathName = "resources/";
        File resourcesPath = new File(resourcesPathName);
        String[] pildinimed = resourcesPath.list();

        assert pildinimed != null;

        Image[] image = new Image[pildinimed.length];
        for(int i = 0; i < pildinimed.length; i++) {
            image[i] = new Image(new FileInputStream(resourcesPathName + pildinimed[i]));
        }
        return image;
    }

    private double fixWindowScreenOffsetX(double x) {
        return x - 16;
    }

    private double fixWindowScreenOffsetY(double y) {
        return y - 39;
    }

    private double getGridSize(double x) {
        return x / GRID_SIZE;
    }

    public static void main(String[] args) {
        launch(args);
    }
}
