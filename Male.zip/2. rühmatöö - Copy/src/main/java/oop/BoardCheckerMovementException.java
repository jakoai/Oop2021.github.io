package oop;

public class BoardCheckerMovementException extends RuntimeException{
    public BoardCheckerMovementException(String msg){
        super(msg);
    }
}
