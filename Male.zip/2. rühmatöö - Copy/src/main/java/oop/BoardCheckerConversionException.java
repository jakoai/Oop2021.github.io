package oop;

public class BoardCheckerConversionException extends RuntimeException{
    public BoardCheckerConversionException(String msg){
        super(msg);
    }
}
