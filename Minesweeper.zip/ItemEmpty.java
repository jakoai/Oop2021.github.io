public class ItemEmpty extends Item{

    public ItemEmpty() {
        super(" ");
    }

    /* Reveal item */
    @Override
    public boolean reveal() {
        if (!getMarked()) {
            setHidden(false);
        }
        return false;
    }
}
