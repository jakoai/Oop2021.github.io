public class Graphics {

    Scene scene;
    private String clearScreen = "\033[H\033[2J"; //ANSI code to clear all the screen

    /* Set specific scene to render */
    public void setScene(Scene scene) {
        this.scene = scene;
    }

    /* Draw screen */
    public void draw() {
        System.out.print(clearScreen+scene.getGraphics());
        System.out.flush();
    }
}
