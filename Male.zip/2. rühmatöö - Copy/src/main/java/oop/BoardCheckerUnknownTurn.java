package oop;

public class BoardCheckerUnknownTurn extends RuntimeException{
    public BoardCheckerUnknownTurn(String msg){
        super(msg);
    }
}
