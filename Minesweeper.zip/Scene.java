public interface Scene {
    String getGraphics();
    Item getItem(int x, int y);
    int[] getSize();
    boolean select(int x, int y, int ch);
}
