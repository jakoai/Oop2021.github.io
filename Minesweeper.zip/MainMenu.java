import java.util.ArrayList;
import java.util.List;

public class MainMenu implements Scene{
    private List<Item> menuItems;
    private int[] selection;

    public MainMenu(){
        generateMenuItems();
    }

    /* Add menu items to render list */
    private void generateMenuItems(){
        menuItems = new ArrayList<>();
        menuItems.add(new ItemMenu(Colors.Green+"Easy 9x9 / 10 bombs"+Colors.Reset));
        menuItems.add(new ItemMenu(Colors.Yellow+"Medium 16x16 / 40 bombs"+Colors.Reset));
        menuItems.add(new ItemMenu(Colors.Red+"Hard 30x16 / 99 bombs"+Colors.Reset));
        menuItems.add(new ItemMenu("EXIT"));
    }

    public int[] getSelection(){
        return selection;
    }

    /* Render main menu */
    @Override
    public String getGraphics() {
        StringBuilder s = new StringBuilder();
        s.append(Colors.Green+Colors.Reversed+"Welcome to console based Minesweeper!"+Colors.Reset+"\n");
        s.append("Mission is to reveal all bombs, without landing on any of them.\n");
        s.append("Please select difficulty:\n");
        for (Item item:menuItems) {
            s.append(item.toString()+"\n");
        }
        s.append(Colors.Reversed+"Move: arrows, Select: enter"+Colors.Reset);
        return s.toString();
    }

    @Override
    public Item getItem(int x, int y) {
        return menuItems.get(y);
    }

    @Override
    public int[] getSize() {
        return new int[]{1, menuItems.size()}; ///< Menu has only one column
    }

    /* Updates the selected difficulty */
    @Override
    public boolean select(int x, int y, int ch) {
        Item item = getItem(x, y);
        switch (y){
            case 0:
                selection = new int[]{9, 9, 10};
                break;
            case 1:
                selection = new int[]{16, 16, 40};
                break;
            case 2:
                selection = new int[]{30, 16, 99};
                break;
            case 3:
                selection = null;
        }
        if (ch == 10){ ///< Enter
            return true;
        }
        return false;
    }
}
