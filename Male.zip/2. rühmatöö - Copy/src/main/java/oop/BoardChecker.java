package oop;

import java.util.*;

public class BoardChecker {
    private String FEN;

    private char[][] board;

    private String castling_w = "";
    private String castling_b = "";
    private String en_passant = null;

    private  boolean fire = false; ///< Is king on fire by enemy's buttons
    private char turn; ///< Whose turn it is

    // Set false, to force checkFire not to be executed, to lookup enemy's side, that cannot have fire on king
    private boolean force_check_fire = true;

    private final Map<Character, String> eatable = new HashMap<>(){{ ///< Edible button depending on turn side
        put('b', "PRBNQK");
        put('w', "prbnqk");
    }};

    public BoardChecker(String FEN){
        this.setFEN(FEN);
    }

    public BoardChecker(String FEN, boolean check_fire){
        this.force_check_fire = check_fire;
        this.setFEN(FEN);
    }

    // FEN Data structure: rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1
    public void setFEN(String FEN) {
        this.FEN = FEN;
        this.parseFEN(FEN);
    }

    //called to switch sides for enemy lookup
    public void setTurn(char turn){
        if (turn == 'w' || turn == 'b') {
            this.turn = turn;
        } else {
            throw new BoardCheckerUnknownTurn("Invalid turn data to set (ex 'w' or 'b'), got: "+turn);
        }
    }

    public char getTurn() {
        return turn;
    }

    // Get tile from the board data
    public char getTile(int x, int y) {
        if (inBoundaries(x, y)) {
            return this.board[y][x];
        }
        throw new BoardCheckerOutOfBounds("Requested tile, that is out of boundaries, X="+x+" Y="+y);
    }

    // Parse in FEN chess data structure, https://en.wikipedia.org/wiki/Forsyth%E2%80%93Edwards_Notation
    private void parseFEN(String FEN){
        board = new char[8][8];

        String[] FEN_data = FEN.split(" ");

        // Parse board buttons locations
        String[] board_data = FEN_data[0].split("/");
        if (board_data.length != 8){
            throw new BoardCheckerParseExceptions("Invalid number of board rows, got length: "+board_data.length);
        }

        for (int row = 0; row < board_data.length; row++) { ///< Iterate board data
            int index = 0; ///< Index of the next data point in column (empty numbers as null or button char)

            for (char tile:board_data[row].toCharArray()) {
                int empty_count = tile-'0';
                if (empty_count >= 1 && empty_count <= 8){ ///< If found empty number value in range
                    index += empty_count; ///< Skip empty columns
                } else {
                    String known_buttons = "rqkbnp"; ///< Known buttons
                    // If found known button, add it to board's columns
                    if (known_buttons.contains(String.valueOf(tile).toLowerCase())){
                        board[row][index] = tile;
                    } else {
                        throw new BoardCheckerParseExceptions("Unknown button to parse in, got: "+tile);
                    }
                    index += 1;
                }
            }
        }

        // Parse players turn
        char[] turn_data = FEN_data[1].toCharArray();
        if (turn_data.length == 1){
            this.setTurn(turn_data[0]);
        } else {
            throw new BoardCheckerParseExceptions("Invalid too much turn information (ex 'w' or 'b'), got: "+FEN_data[1]);
        }

        // Parse castling
        String castling = FEN_data[2];
        if (!castling.equals("-")){
            int index = 0;
            boolean got_info = false;
            if (castling.startsWith("KQ")){
                this.castling_w = "kq";
                index += 2;
                got_info = true;
            } else if (castling.startsWith("K")){
                this.castling_w = "k";
                index += 1;
                got_info = true;
            } else if (castling.startsWith("Q")){
                this.castling_w = "Q";
                index += 1;
                got_info = true;
            }

            if (castling.substring(index).equals("kq")){
                this.castling_b = "kq";
                got_info = true;
            } else if (castling.substring(index).equals("k")){
                this.castling_b = "k";
                got_info = true;
            } else if (castling.substring(index).equals("q")){
                this.castling_b = "q";
                got_info = true;
            }

            if (!got_info){
                throw new BoardCheckerParseExceptions("Invalid castling FEN input (ex KQkq), got: "+castling);
            }
        }

        // Parse En passant
        String en_passant = FEN_data[3];
        if (!en_passant.equals("-")){
            toCoordinateXY(en_passant); ///< Check for valid board coordinate input
            this.en_passant = en_passant;
        }

        // Ignore end of the FEN

        // Check if king on fire
        if (force_check_fire) { ///< Ignore when looking for enemy's side, both kings cannot have fire at the same time
            this.fire = checkFire();
        }
    }

    public boolean checkFire(){
        // Generate new board for enemy side, to look up all fire tiles
        BoardChecker enemy_board = new BoardChecker(generateFEN(), false);
        enemy_board.setTurn(this.turn=='w'?'b':'w'); ///< Switch to enemy side
        enemy_board.setFEN(enemy_board.generateFEN());

        String king_location = null;
        for (int y = 0; y < this.board.length; y++) { ///< Search for alley kings location
            for (int x = 0; x < this.board[y].length; x++) {
                char tile = getTile(x, y);
                if ((this.turn == 'w' && tile == 'K') || (this.turn == 'b' && tile == 'k')){
                    king_location = toCoordinate(x, y);
                    break;
                }
            }
            if (king_location != null) {
                break;
            }
        }

        if (king_location == null){
            throw new BoardCheckerParseExceptions("Cannot find kings locations");
        }

        // Get all enemy's tiles that have fire
        return enemy_board.generateFireTiles().contains(king_location);
    }

    // Looks for all tiles that have alley's buttons creating fire, called by enemy side
    public Set<String> generateFireTiles(){
        Set<String> fire_tiles = new HashSet<>();
        HashMap<Character, String> selectable = new HashMap<>(){{ ///< All possible selectable button in tile
            put('w', "PRNBQK");
            put('b', "prnbqk");
        }};
        for (int y = 0; y < this.board.length; y++) {
            for (int x = 0; x < this.board[y].length; x++) {
                char tile = getTile(x, y);

                if (selectable.get(this.turn).contains(String.valueOf(tile))){
                    switch (String.valueOf(tile).toLowerCase()) {
                        case "p" -> fire_tiles.addAll(EtturFire(x, y));
                        case "r" -> fire_tiles.addAll(MastFire(x, y));
                        case "n" -> fire_tiles.addAll(HobeneFire(x, y));
                        case "b" -> fire_tiles.addAll(OdaFire(x, y));
                        case "q" -> fire_tiles.addAll(LippFire(x, y));
                        case "k" -> fire_tiles.addAll(KuningasFire(x, y));
                    }
                }
            }
        }

        return fire_tiles;
    }

    // Convert board coordinate to world coordinates, a2 -> (0, 7)
    public int[] toCoordinateXY(String cord){
        if (cord.length() == 2) {
            char[] data = cord.toCharArray();
            char col = data[0]; ///< a to h
            char row = data[1]; ///< 1 to 8
            int col_index = col - 'a';
            int row_index = row - '1';
            if (col_index > 7 || col_index < 0) {
                throw new BoardCheckerConversionException("Board column coordinate out of range (a-h), got: "+col);
            }
            if (row_index > 7 || row_index < 0) {
                throw new BoardCheckerConversionException("Board row coordinate out of range (1-8), got: "+row);
            }
            return new int[]{7 - row_index, col_index};
        }
        throw new BoardCheckerConversionException("Invalid board coordinate input (ex a2), got: "+cord);
    }

    // Convert world coordinates to board coordinates, (0, 7) -> a2
    public String toCoordinate(int x, int y){
        StringBuilder str = new StringBuilder();
        if (!inBoundaries(x, y)) {
            throw new BoardCheckerConversionException("Unabled to convert world coordinates to board coordinates: X="+x+" Y="+y);
        }
        str.append((char)('a'+x));
        str.append((char)('8'-y));

        return str.toString();
    }

    public void move(String from, String to){
        int[] from_cord = toCoordinateXY(from); ///< Move button from tile
        int from_y = from_cord[0];
        int from_x = from_cord[1];

        char new_button = 0;
        if (to.length() == 3){
            new_button = to.toCharArray()[2];
        }
        int[] to_cord = toCoordinateXY(to.substring(0, 2)); ///< Move button to tile
        int to_y = to_cord[0];
        int to_x = to_cord[1];

        // En passant
        if (String.valueOf(this.board[from_y][from_x]).equalsIgnoreCase("p")) {
            int direction; ///< Generate movement direction depending on turn
            if (this.turn == 'w') {
                direction = -1;
            } else if (this.turn == 'b') {
                direction = 1;
            } else {
                throw new BoardCheckerMovementException("Unknown pawn turn direction");
            }

            if (from_y+2*direction == to_y){ ///< If button has moved twice in the beginning
                en_passant = toCoordinate(from_x, from_y+direction);
            } else {
                // Check for en passant eat movement
                if (inBoundaries(from_x + 1, from_y + direction)) {
                    if (toCoordinate(from_x + 1, from_y + direction).equals(en_passant)) {
                        this.board[from_y][from_x + 1] = 0;
                    }
                }
                if (inBoundaries(from_x - 1, from_y + direction)) {
                    if (toCoordinate(from_x - 1, from_y + direction).equals(en_passant)) {
                        this.board[from_y][from_x - 1] = 0;
                    }
                }
                en_passant = null;
            }
        } else {
            en_passant = null;
        }

        // Castling control
        if (String.valueOf(this.board[from_y][from_x]).equalsIgnoreCase("k")) {
            if (from_x == 4) {
                int row = this.turn == 'w' ? 7 : 0;
                if (from_x - 2 == to_x) { ///< Queen side castling
                    if (getTile(0, row) == (this.turn == 'w' ? 'R' : 'r') && ///< If invalid movement occur, ignore
                            getTile(1, row) == 0 && getTile(2, row) == 0 && getTile(3, row) == 0) {
                        // Move rook on castling, king is moved by generic mover
                        this.board[row][0] = 0;
                        this.board[row][3] = this.turn == 'w' ? 'R' : 'r';
                    }
                }
                if (from_x + 2 == to_x) { ///< King side castling
                    if (getTile(7, row) == (this.turn == 'w' ? 'R' : 'r') && ///< If invalid movement occur, ignore
                            getTile(6, row) == 0 && getTile(5, row) == 0) {
                        // Move rook on castling, king is moved by generic mover
                        this.board[row][7] = 0;
                        this.board[row][5] = this.turn == 'w' ? 'R' : 'r';
                    }
                }
            }
        }

        // Generic button movement
        if (getTile(from_x, from_y) != 0) {

            // If king moves, remove castling ability
            if (getTile(from_x, from_y) == 'K'){
                this.castling_w = "";
            } else if (getTile(from_x, from_y) == 'k'){
                this.castling_b = "";
            }else if (getTile(from_x, from_y) == 'R'){
                if (from_x == 0){
                    castling_w = castling_w.replace("q", "");
                } else if (from_x == 7){
                    castling_w = castling_w.replace("k", "");
                }
            } else if (getTile(from_x, from_y) == 'r'){
                if (from_x == 0){
                    castling_b = castling_b.replace("q", "");
                } else if (from_x == 7){
                    castling_b = castling_b.replace("k", "");
                }
            }

            // Move button to destination
            if (new_button != 0) {
                this.board[to_y][to_x] = new_button;
            } else {
                this.board[to_y][to_x] = getTile(from_x, from_y);
            }
            this.board[from_y][from_x] = 0;
        } else {
            throw new BoardCheckerMovementException("Cannot move empty tile: fromX="+from_x+" fromY="+from_y);
        }

        this.turn = this.turn=='w'?'b':'w'; ///< Switch turn side
        // Generate new FEN and override current board status
        this.setFEN(generateFEN());
    }

    public String generateFEN(){
        StringBuilder str = new StringBuilder();

        // Add board
        for (char[] row:this.board) {
            int empty_count = 0;
            for (char tile:row) {
                if (tile != 0){
                    if (empty_count != 0){
                        str.append(empty_count);
                    }
                    empty_count = 0;
                    str.append(tile);
                } else {
                    empty_count += 1;
                }
            }
            if (empty_count != 0){
                str.append(empty_count);
            }
            str.append('/');
        }
        str.setLength(str.length()-1); ///< Remove last "/" char

        // Add turn
        str.append(" ").append(this.turn);

        // Add castling
        str.append(' ');
        if (castling_w.equals("") && castling_b.equals("")){
            str.append("-");
        } else {
            if (!castling_w.equals("")) {
                str.append(castling_w.toUpperCase());
            }
            if (!castling_b.equals("")) {
                str.append(castling_b.toLowerCase());
            }
        }

        // Add en passant
        str.append(' ');
        if (en_passant != null){
            str.append(en_passant);
        } else {
            str.append('-');
        }

        // Add useless fen data
        str.append(" 0 1");

        return str.toString();
    }

    // Iterates through all buttons and generates Map for each buttons possible movements
    public HashMap<String, Set<String>> getAllPossibleSteps(){
        // All selectable buttons depending on turn
        HashMap<Character, String> selectable = new HashMap<>(){{
            put('w', "PRNBQK");
            put('b', "prnbqk");
        }};

        HashMap<String, Set<String>> possible = new HashMap<>();

        for (int y = 0; y < this.board.length; y++) {
            for (int x = 0; x < this.board[y].length; x++) {
                if (selectable.get(this.turn).contains(String.valueOf(this.getTile(x, y)))) {
                    Set<String> button = getPossibleSteps(toCoordinate(x, y));
                    possible.put(toCoordinate(x, y), button);
                }
            }
        }
        return possible;
    }

    // Gets all possible locations where selected button can be
    public Set<String> getPossibleSteps(String selected){
        int[] coordinates = toCoordinateXY(selected);
        int y = coordinates[0];
        int x = coordinates[1];

        // All the selectable button depending on turn
        HashMap<Character, String> selectable = new HashMap<>(){{
            put('w', "PRNBQK");
            put('b', "prnbqk");
        }};

        // If selected tile's button is selectable
        if (selectable.get(this.turn).contains(String.valueOf(getTile(x, y)))){
            switch (String.valueOf(getTile(x, y)).toLowerCase()){
                case "p":
                    return EtturMove(x, y);
                case "r":
                    return MastMove(x, y);
                case "n":
                    return HobeneMove(x, y);
                case "b":
                    return OdaMove(x, y);
                case "q":
                    return LippMove(x, y);
                case "k":
                    return KuningasMove(x, y);
            }
        }
        return new HashSet<>();
    }

    // Check if given tile is in boundaries
    private boolean inBoundaries(int x, int y){ //check is board target x and y are in boundaries
        return x >= 0 && x <= 7 && y >= 0 && y <= 7;
    }

    // Goes in direction, find all possible movement tiles for button
    private Set<String> walkThroughRecursive(int x, int y, int direction_x, int direction_y){
        if (inBoundaries(x+direction_x, y+direction_y)){ ///< Check if out of boundaries
            Set<String> recurs_top;
            // Give ability to step on enemy's button and no further movement
            if (eatable.get(this.turn).contains(String.valueOf(getTile(x+direction_x, y+direction_y)))){
                recurs_top = new HashSet<>(){};
                recurs_top.add(toCoordinate(x+direction_x, y+direction_y));
                return recurs_top;
            }
            if (getTile(x+direction_x, y+direction_y) == 0){ ///< Continue if empty spaces
                recurs_top = walkThroughRecursive(x+direction_x, y+direction_y, direction_x, direction_y);
                recurs_top.add(toCoordinate(x+direction_x, y+direction_y));
                return recurs_top;
            }
        }
        return new HashSet<>(); ///< nowhere to move
    }

    private Set<String> removeFireMoves(String from, Set<String> possible){ ///< Filter out all possible button movements, where king can get fire
        Set<String> no_fire = new HashSet<>();
        // Check if not enemy side lookup, since both kings cant have fire at the same time
        if (force_check_fire) {
            // Generate new board to iterate through all possible movements and check for initial fire.
            for (String to : possible) {
                BoardChecker new_board = new BoardChecker(FEN);
                new_board.setTurn(this.turn=='w'?'b':'w'); ///< Reverse turn, because move reverses too;
                new_board.move(from, to);
                if (!new_board.checkFire()) {
                    no_fire.add(to);
                }
            }
        }
        return no_fire;
    }

    // Check ability to castle to the queen side
    private String castlingQueenSide(){

        if (this.fire){ ///< If king already on fire, no castling
            return null;
        }

        int row = this.turn=='w'?7:0;
        // Generate new board to try all king locations, if occurs fire, no castling
        BoardChecker castling = new BoardChecker(FEN);
        // Check if castle still exists
        boolean good = getTile(0, row) == (this.turn=='w'?'R':'r');

        // Check for empty tiles
        if (getTile(1, row) != 0 || getTile(2, row) != 0 || getTile(3, row) != 0){
            good = false;
        }

        // Iterate all king locations
        for (int i = 4; i > 0; i--) {
            castling.setTurn(this.turn=='w'?'b':'w'); ///< Reverse turn because move reverses too
            castling.move(toCoordinate(i, row), toCoordinate(i-1, row));
            if (castling.checkFire()) {
                good = false;
            }
        }
        if (good){
            return toCoordinate(2, row);
        }
        return null;
    }

    // Check ability to castle to the king side
    private String castlingKingSide(){

        // If king already on fire, no castling can happen
        if (this.fire)
            return null;

        int row = this.turn=='w'?7:0;
        // Generate new board to try all king locations, if occurs fire, no castling
        BoardChecker castling = new BoardChecker(FEN);

        boolean good = getTile(7, row) == (this.turn=='w'?'R':'r'); ///< Check if castle still exists

        if (getTile(5, row) != 0 || getTile(6, row) != 0){ ///< Check for empty tiles
            good = false;
        }

        for (int i = 4; i < 7; i++) { ///< Iterate all king locations
            castling.setTurn(this.turn=='w'?'b':'w'); ///< Reverse turn because move reverses too
            castling.move(toCoordinate(i, row), toCoordinate(i+1, row));
            if (castling.checkFire()) {
                good = false;
            }
        }
        if (good){
            return toCoordinate(6, row);
        }
        return null;
    }

    private Set<String> EtturMove(int x, int y){
        Set<String> possible = new HashSet<>();

        int direction; ///< Generate movement direction
        if (this.turn == 'w'){
            direction = -1;
        } else if (this.turn == 'b'){
            direction = 1;
        } else {
            throw new BoardCheckerUnknownTurn("Unknown turn data has been set, must be set by third party (not setTurn)");
        }

        // Check forward movement one tile
        boolean can_move_forward = false;
        if (inBoundaries(x, y+direction)){
            if (getTile(x, y+direction) == 0) {
                can_move_forward = true;
                possible.add(toCoordinate(x, y+direction));
            }
        }

        if (can_move_forward) { ///< If cant move one step, then cant double too
            ///< Check forward movement double in the beginning
            if ((this.turn == 'w' && y == 6) || (this.turn == 'b' && y == 1)) {
                if (inBoundaries(x, y + 2 * direction)) {
                    if (getTile(x, y + 2 * direction) == 0) {
                        possible.add(toCoordinate(x, y + 2 * direction));
                    }
                }
            }
        }

        // Check eat movements
        if (inBoundaries(x+1, y+direction)){
            // Check if can eat and move to the right
            if (eatable.get(this.turn).contains(String.valueOf(getTile(x+1, y+direction)))){
                possible.add(toCoordinate(x+1, y+direction));
            }
        }
        if (inBoundaries(x-1, y+direction)){
            // Check if can eat and move to the left
            if (eatable.get(this.turn).contains(String.valueOf(getTile(x-1, y+direction)))){
                possible.add(toCoordinate(x-1, y+direction));
            }
        }

        // Check en passant
        if (inBoundaries(x+1, y+direction)){
            // Check right eat and movement and passant
            if (toCoordinate(x+1, y+direction).equals(en_passant)){
                possible.add(toCoordinate(x+1, y+direction));
            }
        }
        if (inBoundaries(x-1, y+direction)){
            // Check left eat and movement and passant
            if (toCoordinate(x-1, y+direction).equals(en_passant)) {
                possible.add(toCoordinate(x-1, y+direction));
            }
        }

        return removeFireMoves(toCoordinate(x, y), possible);
    }

    private Set<String> MastMove(int x, int y){
        Set<String> possible = MastFire(x, y); ///< Get all the location rook can go and eat
        return removeFireMoves(toCoordinate(x, y), possible);
    }

    private Set<String> HobeneMove(int x, int y){
        Set<String> possible = HobeneFire(x, y); ///< Get all the location horse can go and eat
        return removeFireMoves(toCoordinate(x, y), possible);
    }

    private Set<String> OdaMove(int x, int y){
        Set<String> possible = OdaFire(x, y); ///< Get all the location bishop can go and eat
        return removeFireMoves(toCoordinate(x, y), possible);
    }

    private Set<String> LippMove(int x, int y){
        Set<String> possible = new HashSet<>();
        possible.addAll(MastMove(x, y));
        possible.addAll(OdaMove(x, y));
        return possible;
    }

    private Set<String> KuningasMove(int x, int y){
        Set<String> possible = KuningasFire(x, y); ///< Get all location where king can move and eat

        // Check castling movement
        if (this.turn == 'w') {
            if (castling_w.contains("k")) { ///< White turn king side
                String c = castlingKingSide();
                if (c != null){
                    possible.add(c);
                }
            }
            if (castling_w.contains("q")) { ///< White turn queen side
                String q = castlingQueenSide();
                if (q != null){
                    possible.add(q);
                }
            }
        } else if (this.turn == 'b') {
            if (castling_b.contains("k")) { ///< Black turn king side
                String c = castlingKingSide();
                if (c != null){
                    possible.add(c);
                }
            }
            if (castling_b.contains("q")) { ///< Black turn queen side
                String q = castlingQueenSide();
                if (q != null){
                    possible.add(q);
                }
            }
        }

        return removeFireMoves(toCoordinate(x, y), possible);
    }

    private Set<String> EtturFire(int x, int y){
        Set<String> possible = new HashSet<>();

        int direction; ///< Generate movement direction

        if (this.turn == 'w'){
            direction = -1;
        } else if (this.turn == 'b'){
            direction = 1;
        } else {
            throw new BoardCheckerUnknownTurn("Unknown turn data has been set, must be set by third party (not setTurn)");
        }

        // Check places where pawn can eat normal buttons (no enpassant)
        if (inBoundaries(x+1, y+direction)){
            if (!eatable.get(this.turn=='w'?'b':'w').contains(String.valueOf(getTile(x+1, y+direction)))) { //if can eat on right side
                possible.add(toCoordinate(x + 1, y + direction));
            }
        }
        if (inBoundaries(x-1, y+direction)){
            if (!eatable.get(this.turn=='w'?'b':'w').contains(String.valueOf(getTile(x-1, y+direction)))) {//if can eat on left side
                possible.add(toCoordinate(x - 1, y + direction));
            }
        }
        return possible;
    }

    private Set<String> MastFire(int x, int y){
        Set<String> possible = new HashSet<>();

        // Define all direction where rook can go
        possible.addAll(walkThroughRecursive(x, y, 1, 0));
        possible.addAll(walkThroughRecursive(x, y, -1, 0));
        possible.addAll(walkThroughRecursive(x, y, 0, 1));
        possible.addAll(walkThroughRecursive(x, y, 0, -1));
        return possible;
    }


    private Set<String> HobeneFire(int x, int y){
        Set<String> possible = new HashSet<>();

        // All locations where horse can move
        int[][] locations = new int[][]{{x+1, y+2}, {x-1, y+2}, {x+1, y-2}, {x-1, y-2},
                                        {x+2, y+1}, {x-2, y+1}, {x+2, y-1}, {x-2, y-1}};
        for (int[] loc:locations) {
            if (inBoundaries(loc[0], loc[1])){
                // Check for empty spot to jump
                if (getTile(loc[0], loc[1]) == 0){
                    possible.add(toCoordinate(loc[0], loc[1]));
                    continue;
                }
                // Check if can eat something
                if (eatable.get(this.turn).contains(String.valueOf(getTile(loc[0], loc[1])))){
                    possible.add(toCoordinate(loc[0], loc[1]));
                }
            }
        }
        return possible;
    }

    private Set<String> OdaFire(int x, int y){
        Set<String> possible = new HashSet<>();

        // Define all ways that bishop can move
        possible.addAll(walkThroughRecursive(x, y, 1, 1));
        possible.addAll(walkThroughRecursive(x, y, -1, 1));
        possible.addAll(walkThroughRecursive(x, y, 1, -1));
        possible.addAll(walkThroughRecursive(x, y, -1, -1));

        return possible;
    }

    private Set<String> LippFire(int x, int y){
        Set<String> possible = new HashSet<>();
        possible.addAll(MastFire(x, y));
        possible.addAll(OdaFire(x, y));
        return possible;
    }

    private Set<String> KuningasFire(int x, int y){
        Set<String> fire = new HashSet<>();

        int[] x_range = new int[]{-1, 0, 1};
        int[] y_range = new int[]{-1, 0, 1};

        for (int x_r:x_range) {
            for (int y_r:y_range) {
                if (inBoundaries(x+x_r, y+y_r)){
                    if (getTile(x+x_r, y+y_r) == 0){ ///< If tile is free
                        fire.add(toCoordinate(x+x_r, y+y_r));
                        continue;
                    }
                    // If tile has enemy button to eat
                    if (eatable.get(this.turn).contains(String.valueOf(getTile(x+x_r, y+y_r)))){
                        fire.add(toCoordinate(x+x_r, y+y_r));
                    }
                }
            }
        }
        return fire;
    }

    @Override
    public String toString() {
        StringBuilder str = new StringBuilder("BoardChecker{" +
                "FEN='" + generateFEN() + '\'' +
                ", castling_w='" + castling_w + '\'' +
                ", castling_b='" + castling_b + '\'' +
                ", en_passant='" + en_passant + '\'' +
                ", turn=" + turn +
                ", fire=" + this.fire +
                '}'+'\n');

        for (char[] row:this.board) {
            for (char i:row) {
                str.append(String.format("%c ", i==0?' ':i)); ///< Format to make table look good (readable)
            }
            str.append('\n');
        }
        return str.toString();
    }


    // Test function
    public static void main(String[] args) {
        BoardChecker b = new BoardChecker("rnbqkbnr/pppppppp/P7/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1");
        System.out.println(b);
        b.move("a6", "b7");
        System.out.println(b);
        b.move("a7", "a5");
        System.out.println(b);
        b.move("a2", "a3");
        System.out.println(b);
        b.move("c7", "c6");
        System.out.println(b);
        System.out.println(b.getAllPossibleSteps());
    }
}