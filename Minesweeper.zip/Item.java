public abstract class Item {
    private String text;
    private boolean ishidden = true;
    private boolean marked = false;
    private boolean selected = false;

    public Item(String text){
        this.text = text;
    }

    /* Output item color and text as hidden */
    public void setHidden(boolean h){
        ishidden = h;
    }

    public boolean getHidden(){
        return ishidden;
    }

    /* Toggle hidden item to be marked and return last state */
    public boolean toggleMarked(){
        return marked = !marked;
    }
    public boolean getMarked(){
       return marked;
    }

    /* If item is selected by user */
    public void setSelected(boolean s){
        selected = s;
    }

    public boolean getSelected(){
        return selected;
    }

    /* Show text when item is not hidden */
    String getText(){
        if (ishidden) {
            return " ";
        } else {
            return text;
        }
    }

    /* Defined default color */
    public String color(){ return Colors.Reset;}

    /* Generate color based on item state */
    String getColor(){
        String color = "";
        if (getHidden()){
            if (getMarked()){
                color += Colors.color((byte) 124);
                color += Colors.BackgroundRed;
            } else {
                color += Colors.backgroundColor((byte)8);
            }
        } else {
            color += color();
        }
        if (selected){
            color += Colors.Reversed;
        }
        return color;
    }

    public boolean isBomb(){
        return false;
    }

    public boolean isEmpty(){
        return true;
    };

    public abstract boolean reveal();

    // Return rendered item
    @Override
    public String toString() {
        return getColor()+" "+getText()+Colors.Reset;
    }
}
