module male {
  requires javafx.controls;
  requires javafx.fxml;

  exports oop;
}
