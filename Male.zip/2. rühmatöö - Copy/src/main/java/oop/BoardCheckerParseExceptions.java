package oop;

public class BoardCheckerParseExceptions extends RuntimeException{
    public BoardCheckerParseExceptions(String msg){
        super(msg);
    }
}
