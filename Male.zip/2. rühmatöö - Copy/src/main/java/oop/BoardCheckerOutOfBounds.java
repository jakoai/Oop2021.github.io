package oop;

public class BoardCheckerOutOfBounds extends RuntimeException{
    public BoardCheckerOutOfBounds(String msg){
        super(msg);
    }
}
