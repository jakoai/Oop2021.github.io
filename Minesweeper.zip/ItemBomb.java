public class ItemBomb extends Item {

    public ItemBomb() {
        super("o");
    }

    /* Set cursor color red when selected, called after explosion */
    @Override
    public String color() {
        if (getSelected()){
            return Colors.Red+Colors.Reversed;
        }
        return  Colors.Reset;
    }

    /* Reveal bomb when not marked and return true to stop the game */
    @Override
    public boolean reveal() {
        if (!getMarked()) {
            setHidden(false);
            return true;
        }
        return false;
    }

    @Override
    public boolean isEmpty() {
        return false;
    }

    @Override
    public boolean isBomb() {
        return true;
    }
}
